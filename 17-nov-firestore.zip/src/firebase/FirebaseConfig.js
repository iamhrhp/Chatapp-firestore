// Import the functions you need from the SDKs you need
import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';

const firebaseConfig = {
  apiKey: 'AIzaSyB1yGJsR1UVs5kV0PNYzpxm4Mu28F0h9hc',
  authDomain: 'chat-app-96627.firebaseapp.com',
  databaseURL: 'https://chat-app-96627-default-rtdb.firebaseio.com',
  projectId: 'chat-app-96627',
  storageBucket: 'chat-app-96627.appspot.com',
  messagingSenderId: '723589515351',
  appId: '1:723589515351:web:560a1d2843b1dcc5963b12',
  measurementId: 'G-BRLFDKLDSM',
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
export const storage = getStorage(app);
